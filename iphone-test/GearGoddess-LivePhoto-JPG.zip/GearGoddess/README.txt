Mythical Wallpapers Live Photo

On iPhone:
1. In Files, tap this zip once. It unzips into a folder.
2. Open the folder. Tap the three dots (or Select), then tap BOTH the photo (.HEIC or .JPG) and the .MOV.
3. Tap Share, then Save 2 Items.
4. Open Photos. The newest picture should say LIVE in the top corner. Press and hold it to see it move.
Save both files together in one go. Saving them one at a time gives a plain photo and a separate video.
