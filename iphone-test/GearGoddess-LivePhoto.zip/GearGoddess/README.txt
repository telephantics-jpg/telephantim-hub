Mythical Wallpapers Live Photo

1. Tap this zip in Files to unzip it.
2. Open the folder, tap Select, select BOTH the .JPG and the .MOV.
3. Tap Share > Save 2 Items (or Save to Photos). Photos shows LIVE on the new picture.
